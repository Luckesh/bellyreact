<?php
include 'includes/header.php';
?>
<div class="wrapper">

<?php
include 'includes/games.php';
?>

</div>

<?php
include 'includes/footer.php';
?>

